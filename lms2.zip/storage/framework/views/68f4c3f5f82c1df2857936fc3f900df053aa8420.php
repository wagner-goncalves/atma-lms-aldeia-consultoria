<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>" translate="no">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'SIPAT 2020')); ?></title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <meta name="google" content="notranslate">
    <script src="https://kit.fontawesome.com/2c7146b1c7.js" crossorigin="anonymous"></script>

</head>

<body class="bg-banner">
    <div id="app" style="background-color: white">


        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <?php if(auth()->guard()->guest()): ?>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    LMS Aldeia Consultoria
                </a>
            <?php else: ?>
                <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
                    LMS Aldeia Consultoria
                </a>
            <?php endif; ?>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div style="width: 100%">
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link " href="<?php echo e(route('login')); ?>"><?php echo e(__('Faça o login')); ?></a></li>
                            <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Cadastre-se')); ?></a></li>
                        <?php else: ?>
                            
                            <li><span class="nav-link font-weight-bold"><?php echo e(Auth::user()->name); ?></span></li>
                            <li><a class="nav-link" href="<?php echo e(route('home')); ?>">Acessar Curso</a></li>
                            <?php if(auth()->check() && auth()->user()->hasRole('Admin|Gestor')): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Administração
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">Usuários</a>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Gestor')): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('matriculas.index')); ?>">Matrículas</a>
                                    <?php endif; ?>
                                    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item small"><strong>Clientes</strong></a>
                                    <a class="dropdown-item" href="<?php echo e(route('planos.index')); ?>">Planos</a> 
                                    <a class="dropdown-item" href="<?php echo e(route('empresas.index')); ?>">Empresas</a>                                    
                                    <a class="dropdown-item" href="<?php echo e(route('matriculas.index')); ?>">Matrículas</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item small"><strong>Conteúdo</strong></a>
                                    <a class="dropdown-item" href="<?php echo e(route('modulos.index')); ?>">Módulos</a>
                                    <a class="dropdown-item" href="<?php echo e(route('aulas.index')); ?>">Aulas</a>
                                    <a class="dropdown-item" href="<?php echo e(route('materiais.index')); ?>">Materiais</a>
                                    <?php endif; ?>
                                </div>
                            </li>
                            <?php endif; ?>

                            <li><a class="nav-link" href="<?php echo e(route('userslogged.index')); ?>">Meus dados</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">Sair</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>


                        <?php endif; ?>
                    </ul>
                </div>
                <?php if(Request::path() == 'quizzes/responder' && isset($quizz)): ?>
                    <h4 class="pt-4 text-right"><?php echo $quizz->nome; ?></h4>
                <?php endif; ?>
            </div>
        </nav>




        <main class="py-4">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

        <!-- FOOTER -->
        <footer>
            <div class="container-fluid bg-banner">
                <div class="row">
                    <div class="col-md-12 py-3 px-3 text-white font-weight-bold text-center">
                        Aldeia Consultoria © <?php echo e(date('Y')); ?> | Todos os direitos reservados.
                    </div>
                </div>
            </div>
            <footer>

    </div>

</body>

</html>
<?php /**PATH D:\Atma\lms\resources\views/layouts/app.blade.php ENDPATH**/ ?>