<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">

                <div class="titulo-destaque">
                    <i class="fas fa-users"></i>
                    Fórum de discussão
                </div>

            </div>
            <hr />
            <div>
                <div class="row">
                    <div class="col-12 col-md-8 col-sm-12">
                        <h1><?php echo e($curso->nome); ?></h1>
                    </div>
                    <div class="col-12 col-md-4 col-sm-12 text-right">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-success"><i class="fas fa-chevron-left"></i> Voltar</a>
                    </div>
                </div>


                <div class="row">
                    <div class="col-12">
                        <h3>Postagens</h3>
                    </div>
                </div>

                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <p><strong>Whoops!</strong> Temos alguns problemas.</p>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <i class="fas fa-exclamation-circle fa-lg"></i> <?php echo e($message); ?>

                    </div>
                <?php endif; ?>
                <?php if(count($errors) == 0): ?>
                <div class="row">
                    <div class="col-12 col-md-8 col-sm-12 mb-3">
                        <div class="mt-100">
                            <script>
                                $(document).ready(function() {
                                    $(document).on('click', ".reply-button", function() {
                                        var post_id = $(this).data('post_id');
                                        var possuiTextArea = $("#reply-post-" + post_id + " textarea")
                                            .length > 0;

                                        if (!possuiTextArea) {
                                            $("#reply-post-" + post_id).html("");
                                            $("#reply-post-" + post_id).append(
                                                '<textarea placeholder="Seu texto..." cols="50" rows="5" class="form-control mb-2" name="reply-textbox-' +
                                                post_id + '" id="reply-textbox-' + post_id +
                                                '"></textarea>');
                                            $("#reply-textbox-" + post_id).focus();
                                        } else {
                                            $("#reply-post").val($("#reply-textbox-" + post_id).val());
                                            $("#reply-post_id").val(post_id);
                                            $("#reply-form").submit();
                                        }

                                    });
                                });

                            </script>

                            <?php echo Form::open(['route' => ['posts.store', ['curso_id' => $curso->id]], 'method' => 'POST', 'id'
                            => 'reply-form']); ?>

                            <?php echo e(Form::hidden('post', '', ['id' => 'reply-post'])); ?>

                            <?php echo e(Form::hidden('post_id', '', ['id' => 'reply-post_id'])); ?>

                            <?php echo Form::close(); ?>


                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <div class="card mb-4">
                                    <div class="card-header">
                                        <div class="media flex-wrap w-100 align-items-center">
                                            <!--<img
                                                                        src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1574583246/AAA/2.jpg"
                                                                        class="d-block ui-w-40 rounded-circle" alt=""> -->
                                            <div class="media-body">
                                                <strong><?php echo e($post->user->name); ?></strong>
                                                <div class="text-muted small">
                                                    <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->created_at))->diffForHumans()); ?>

                                                </div>
                                            </div>
                                            <div class="text-muted small ml-3">
                                                <div>Matriculado em
                                                    <strong><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($post->user->created_at))->format('d/m/Y')); ?></strong>
                                                </div>
                                                <div><strong><?php echo e($post->user->countPosts()); ?></strong> postagens</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <p> <?php echo $post->post; ?> </p>

                                        <?php
                                        $postsFilhos = $post->filhos()->orderBy("id", "desc");
                                        ?>

                                        <?php $__currentLoopData = $postsFilhos->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postFilho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card mb-4 small">
                                                <div class="card-header p-2">
                                                    Respondido por: <strong><?php echo e($postFilho->user->name); ?></strong>
                                                    <div class="text-muted small">
                                                        <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($postFilho->created_at))->diffForHumans()); ?>

                                                    </div>
                                                </div>
                                                    <div class="card-body p-2">
                                                        <?php echo e($postFilho->post); ?>

                                                    </div>
                                                
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <div id="reply-post-<?php echo e($post->id); ?>"></div>
                                        <button type="button" class="btn btn-primary btn-sm reply-button"
                                            data-post_id="<?php echo e($post->id); ?>"><i class="fa fa-reply"></i>&nbsp; Responder</button>
                                        <?php if(auth()->check() && auth()->user()->hasRole('Admin|Gestor')): ?>
                                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['posts.destroy', $post->id], 'style'
                                        => 'display:inline']); ?>

                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                class="fas fa-trash"></i></button>
                                        <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>




                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="row mt-3">
                                    <div class="col">

                                        <div class="alert alert-danger" role="alert">
                                            Nenhuma mensagem postada para o curso.
                                        </div>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="col-12 col-md-4 col-sm-12 mb-3">
                        <div class="card" style="width: 100%">
                            <div class="list-group">
                                <span class="list-group-item list-group-item-action flex-column align-items-start active">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1">Postar no fórum do curso</h5>
                                    </div>
                                </span>

                                <?php echo Form::open(['route' => ['posts.store', ['curso_id' => $curso->id]], 'method' => 'POST',
                                'enctype' => 'multipart/form-data', 'id' => 'edit-form']); ?>

                                <div class="card-body">
                                    <div class="form-group">
                                        <?php echo Form::textarea('post', null, ['placeholder' => 'Seu texto', 'class' =>
                                        'form-control', 'id' => 'descricao']); ?>

                                    </div>
                                    <div>
                                        <button type="submit"
                                            class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase">Postar</button>
                                    </div>
                                </div>
                                <?php echo Form::close(); ?>


                            </div>
                        </div>
                    </div>



                </div>
                <?php endif; ?>



                <?php if($posts): ?>
                    <div class="row mt-3">
                        <div class="col-lg-12 mb-3 text-right">
                            <?php echo $posts->appends(request()->query())->links(); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/posts/index.blade.php ENDPATH**/ ?>