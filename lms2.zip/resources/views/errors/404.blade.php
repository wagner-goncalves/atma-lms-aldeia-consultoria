@extends('errors::minimal')

@section('title', __('Não encontrado'))
@section('code', '404')
@section('message', __('A página que você procura não foi encontrada.'))
