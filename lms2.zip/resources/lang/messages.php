<?php

return [

    'Showing' => 'Exibindo',

];