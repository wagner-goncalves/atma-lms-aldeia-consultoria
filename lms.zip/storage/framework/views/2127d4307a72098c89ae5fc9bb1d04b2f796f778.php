


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <i class="fas fa-edit"></i> Alterar meus dados
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 margin-tb">

            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('home')); ?>"
                            class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                                class="fas fa-chevron-left"></i> Voltar</a>
                    </div>
                </div>
            </div>


            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <p><strong>Whoops!</strong> Temos alguns problemas.</p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e($message); ?>

                </div>
            <?php endif; ?>
            <?php echo Form::model($user, ['method' => 'PATCH', 'route' => ['userslogged.update', $user->id]]); ?>

            <div class="row">
                
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                Nome
                                <?php echo Form::text('name', null, ['placeholder' => '', 'class' => 'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                E-mail
                                <?php echo Form::text('email', null, ['placeholder' => '', 'class' => 'form-control', 'readonly']); ?>

                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                CPF
                                <?php echo Form::text('cpf', null, ['placeholder' => '', 'class' => 'form-control', 'readonly']); ?>

                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                Telefone
                                <?php echo Form::text('phone', null, ['placeholder' => '', 'class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                </div>                


                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                Senha
                                <?php echo Form::password('password', ['placeholder' => '', 'class' => 'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                Confirmar Senha<
                                <?php echo Form::password('confirm-password', ['placeholder' => '', 'class' => 'form-control']); ?>

                            </div>
                        </div>
                    </div>
                </div>                  


                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                                    class="fas fa-save"></i> Salvar</button>
                            </div>
                        </div>
                    </div>
                </div>   

                
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/users/edit-logged.blade.php ENDPATH**/ ?>