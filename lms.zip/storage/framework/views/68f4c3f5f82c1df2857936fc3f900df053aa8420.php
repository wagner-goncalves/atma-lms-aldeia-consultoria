<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>" translate="no">

<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="bg-banner">
    <div id="app" style="background-color: white">

        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <script>
        $(window).load(function(){
            $.ajaxSetup({
                statusCode: {
                    419: function(){
                            location.reload(); 
                        }
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH D:\Atma\lms\resources\views/layouts/app.blade.php ENDPATH**/ ?>