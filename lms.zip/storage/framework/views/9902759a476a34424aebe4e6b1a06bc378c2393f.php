<?php $Str = app('Illuminate\Support\Str'); ?>

<?php $__env->startSection('content'); ?>

    <div class="mb-4">
        <img class="img-fluid" style="width:100%" src="<?php echo e(asset('images/banner-curso.png')); ?>" />
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <?php if(auth()->check() && auth()->user()->hasRole('Aluno')): ?>
                <div>
                    <?php $__empty_1 = true; $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row mb-2">
                            <div class="col-9">
                                <!-- <h1><?php echo e($curso->nome); ?></h1> -->
                            </div>
                            <div class="col-3 text-right">
                                <a href="<?php echo e(route('posts.show', ['post' => $curso->id])); ?>" class="btn btn-danger pull-right"><i
                                        class="fa fa-users"></i> Fórum de
                                    discussão</a>
                            </div>
                        </div>

                        <?php
                        $percentualConclusao = $curso->percentualConclusao();
                        $feedbackRespondido = $curso->feedbackRespondido();
                        $matricula = $curso->matricula();
                        $ultimaAulaVisualizada = $curso->ultimaAulaVisualizada();
                        $tempoRestanteCurso = $curso->tempoRestanteCurso();
                        $ultimaOrdemVisualizada = empty($ultimaAulaVisualizada) ? 0 : $ultimaAulaVisualizada->ordem;
                        ?>

                        <div class="row mb-4">
                            <div class="col-12">
                                <div class="progress" style="height: 30px;">
                                    <div class="progress-bar bg-success" role="progressbar"
                                        style="width: <?php echo e($percentualConclusao); ?>%" aria-valuenow="<?php echo e($percentualConclusao); ?>"
                                        aria-valuemin="0" aria-valuemax="100"><?php echo e($percentualConclusao); ?>%</div>
                                </div>
                            </div>
                            <div class="col-12">
                                <?php if($tempoRestanteCurso >= 0): ?>
                                    Você tem <?php echo e($tempoRestanteCurso); ?> <?php echo e(Str::plural('dia', $tempoRestanteCurso)); ?> para
                                    concluir o
                                    curso.
                                <?php else: ?>
                                    <div class="alert alert-danger mt-3" role="alert">
                                        <div class="media">
                                            <i class="fa fa-2x fa-info-circle"></i>
                                            <div class="media-body ml-3 mt-1">
                                                <b>O prazo para visualização das aulas expirou em
                                                    <?php echo e(\Carbon\Carbon::parse($matricula->data_limite)->format('d/m/Y')); ?></b>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <hr />
                        <div class="pull-left">
                            <div class="titulo-destaque">
                                <i class="fas fa-chalkboard-teacher"></i>
                                Confira a trilha de aprendizado.
                            </div>
                        </div>

                        <p><?php echo $curso->descricao; ?></p>

                        <?php $__empty_2 = true; $__currentLoopData = $curso->modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                            <div class="row no-gutters mb-4">
                                <div class="col-md-4 p-3 mb-2 bg-info-aldeia text-white">
                                    <?php if($modulo->modulo_padrao == 1): ?>
                                    <h3 class="font-weight-bold">Módulo <?php echo e($modulo->ordem); ?></h3>
                                    <h5><?php echo e($modulo->nome); ?></h5>
                                    <?php else: ?>
                                    <h3 class="font-weight-bold"><?php echo e($modulo->nome); ?></h3>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <div class="media mb-3">
                                            <i class="fa fa-2x fa-fw fa-clock"></i>
                                            <div class="media-body ml-3">
                                                <?php
                                                $carga = $modulo->cargaHoraria();
                                                ?>
                                                <b><?php echo e($carga); ?> <?php echo e(Str::plural('hora', $carga)); ?></b>
                                            </div>
                                        </div>

                                        <?php
                                        $materiais = $modulo->materiais()->get();
                                        ?>  

                                        <?php if(count($materiais) > 1): ?>                                      
                                        <div class="media mb-3">
                                            <i class="fa fa-2x fa-fw fa-download"></i>
                                            <div class="media-body ml-3">
                                                <?php $__currentLoopData = $materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <a class="btn btn-sm btn-link" href="<?php echo e(route('materiais.download', ['id' => $material->id])); ?>"><?php echo e($material->titulo); ?></a>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>  
                                        <?php endif; ?>                                      

                                        <div class="media mb-4">
                                            <i class="fa fa-2x fa-fw fa-clipboard"></i>
                                            <div class="media-body ml-3">
                                                <?php echo $modulo->descricao; ?>

                                            </div>
                                        </div>

                                        <table class="table table-striped table-sm table-hover">
                                            <tbody>
                                                <?php $__empty_3 = true; $__currentLoopData = $modulo->aulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                                    <tr>
                                                        <td class="pl-2">
                                                            <?php
                                                            $linkAberto = ($tempoRestanteCurso >=0 && $aula->ordem <=
                                                                intval($ultimaOrdemVisualizada) + 1); ?> <?php if($linkAberto): ?>
                                                                <?php if($aula->ordem <= $ultimaOrdemVisualizada): ?>
                                                                    <i class="fa fa-fw fa-check text-success"></i>
                                                                <?php elseif($aula->ordem == intval($ultimaOrdemVisualizada) + 1): ?>
                                                                    <i class="fa fa-fw fa-lock-open text-success"></i>
                                                                <?php endif; ?>
                                                                <i class="fa fa-fw fa-video"></i> <a
                                                                    href="<?php echo e(route('aula', ['curso' => $curso->id, 'page' => $aula->ordem])); ?>"><?php echo e($aula->titulo); ?></a>
                                                                <span class="badge badge-secondary"><?php echo e(round($aula->carga_horaria / 60, 2)); ?>

                                                                    <?php echo e(Str::plural('hora', round($aula->carga_horaria / 60, 0))); ?></span>
                                                            <?php else: ?>
                                                                <?php if($tempoRestanteCurso < 0 && $aula->ordem <= $ultimaOrdemVisualizada): ?>
                                                                    <i class="fa fa-fw fa-check text-success"></i>
                                                                <?php else: ?>
                                                                    <i class="fa fa-fw fa-lock text-danger"></i> <i
                                                                        class="fa fa-video"></i>
                                                                <?php endif; ?>
                                                                <?php echo e($aula->titulo); ?> <span
                                                                    class="badge badge-secondary"><?php echo e($aula->carga_horaria); ?>

                                                                    <?php echo e(Str::plural('hora', $aula->carga_horaria)); ?></span>
                                                                <?php endif; ?>
                                                        </td>
                                                        <?php if($linkAberto): ?>
                                                            <td class="text-right">
                                                                <?php
                                                                $materiais = $aula->materiais()->get();
                                                                ?>

                                                                <?php if(count($materiais) > 1): ?>
                                                                    <a class="btn btn-sm btn-primary"
                                                                        href="<?php echo e(route('aula', ['curso' => $curso->id, 'page' => $aula->ordem])); ?>"><i
                                                                            class="fas fa-download" aria-hidden="true"></i> <i
                                                                            class="fas fa-ellipsis-h" aria-hidden="true"></i> </a>
                                                                <?php elseif(count($materiais) == 1): ?>
                                                                    <a class="btn btn-sm btn-primary"
                                                                        href="<?php echo e(route('materiais.download', ['id' => $materiais[0]->id])); ?>"><i
                                                                            class="fas fa-download" aria-hidden="true"></i></a>
                                                                <?php endif; ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td class="text-right">&nbsp;</td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                                    <p>Nenhuma aula.</p>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <p>Nenhum módulo.</p>
                        <?php endif; ?>


                        <div class="row no-gutters mb-4">
                            <div class="col-md-4 p-3 mb-2 bg-secondary text-white">
                                <h3 class="font-weight-bold">Feedback do curso</h3>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <div class="media mb-3">
                                        <i class="fa fa-2x fa-stack-exchange" aria-hidden="true"></i>
                                        <div class="media-body ml-3">
                                            Ajude-nos a melhorar nossos treinamentos e aulas. O feedback será liberado após a
                                            visualização de todos os vídeos.
                                        </div>
                                    </div>
                                    <table class="table table-striped table-sm table-hover mb-0">
                                        <tbody>
                                            <tr>
                                                <td class="pl-2">
                                                    <?php if($percentualConclusao != 100): ?>
                                                        <i class="fa fa-fw fa-lock text-danger" aria-hidden="true"></i>
                                                        <i class="fa fa-clipboard-check" aria-hidden="true"></i> Responder
                                                        feedback
                                                    <?php else: ?>

                                                        <?php if($feedbackRespondido): ?>
                                                            <i class="fa fa-fw fa-check text-success"></i>
                                                            <i class="fa fa-clipboard-check" aria-hidden="true"></i>
                                                            Feedback respondido
                                                        <?php else: ?>
                                                            <i class="fa fa-fw fa-lock-open text-success"></i>
                                                            <i class="fa fa-clipboard-check" aria-hidden="true"></i>
                                                            <a href="<?php echo e(route('feedback', ['curso' => $curso->id])); ?>">Responder
                                                                feedback</a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                </div>
                            </div>
                        </div>

                        <div class="row no-gutters mb-4">
                            <div class="col-md-4 p-3 mb-2 bg-success text-white">
                                <h3 class="font-weight-bold">Emitir certificado</h3>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <div class="media mb-3">
                                        <i class="fa fa-2x fa-file-signature" aria-hidden="true"></i>
                                        <div class="media-body ml-3">
                                            O certificado será liberado após a visualização de todos os vídeos e conclusão do
                                            feedback.
                                        </div>
                                    </div>
                                    <table class="table table-striped table-sm table-hover mb-0">
                                        <tbody>
                                            <tr>
                                                <td class="pl-2">
                                                    <?php if($feedbackRespondido): ?>
                                                        <i class="fa fa-fw fa-lock-open text-success"></i>
                                                        <i class="fa fa-file" aria-hidden="true"></i>
                                                        <a href="<?php echo e(route('certificado.download', ['curso' => $curso->id])); ?>">Emitir
                                                            certificado</a>
                                                    <?php else: ?>
                                                        <i class="fa fa-fw fa-lock text-danger" aria-hidden="true"></i>
                                                        <i class="fa fa-file" aria-hidden="true"></i> Emitir certificado
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-right">
                                                    <a class="btn btn-sm btn-primary"
                                                        href="<?php echo e(route('certificado.download', ['curso' => $curso->id])); ?>"><i
                                                            class="fas fa-download" aria-hidden="true"></i></a>
                                                    </form>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Nenhum curso.</p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>


                <div class="row my-3">
                    
                    <?php if(auth()->check() && auth()->user()->hasRole('Gestor')): ?>
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-user"></i>
                                    Você é gestor da plataforma.</h5>
                                <p class="card-text">Olá. Seja bem vindo a plataforma do curso <strong>PROGRAMA CORPORATIVO
                                        GESTANTES E FUTUROS
                                        PAIS</strong>.</p>
                                <p class="card-text">O seu perfil de usuário te possibilita realizar o cadastro dos
                                    colaboradores da sua empresa que terão
                                    acesso ao curso. </p>
                                <p class="card-text">Você pode realizar este cadastro acessando a opção <strong>USUÁRIOS no
                                        menu superior desta
                                        página</strong>. Este cadastro pode ser realizado de forma individualizada ou
                                    através de
                                    importação de uma planilha EXCEL com todos os colaboradores a serem cadastrados no
                                    curso.</p>
                                <p class="card-text">Consulte a equipe da Aldeia Consultoria para obter mais informações
                                    sobre este procedimento.</p>

                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-users"></i>
                                    Você é administrador da plataforma.</h5>
                                <p class="card-text">Você está logado como administrador da plataforma e possui acesso
                                    irrestrito a todas as
                                    funcionalidades do sistema.</p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>                    
                </div>





            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/home.blade.php ENDPATH**/ ?>