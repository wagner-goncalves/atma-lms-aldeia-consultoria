<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">

                <div class="titulo-destaque">
                    <i class="fas fa-video"></i>
                    Assistir aula
                </div>

            </div>
            <hr />
            <div>
                <div class="row">
                    <div class="col-12 col-md-8 col-sm-12">
                        <h1><?php echo e($curso->nome); ?></h1>
                    </div>
                    <div class="col-12 col-md-4 col-sm-12 text-right">
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-success"><i class="fas fa-chevron-left"></i> Voltar</a>
                        <a href="<?php echo e(route('posts.show', ['post' => $curso->id])); ?>" class="btn btn-danger pull-right"><i class="fa fa-users"></i> Fórum de discussão</a>
                        
                    </div>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $aulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row">
                        <div class="col-12">
                            <h3>Módulo <?php echo e($aula->modulo->ordem); ?> - Aula: <?php echo e($aula->titulo); ?></h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-8 col-sm-12 mb-3">
                            <div class="embed-responsive embed-responsive-16by9">
                                <?php echo sprintf('<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/%s?controls=0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>', $aula->link); ?>

                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-sm-12 mb-3">

                            <?php if($aula->descricao != ""): ?>
                            <div class="card mb-2" style="width: 100%">
                                <div class="list-group">
                                    <span class="list-group-item list-group-item-action flex-column align-items-start active">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h5 class="mb-1">Sobre esta aula</h5>
                                        </div>
                                    </span>

                                        <span class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <?php echo $aula->descricao; ?>

                                            </div>
                                        </span>
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="card" style="width: 100%">
                                <div class="list-group">
                                    <span class="list-group-item list-group-item-action flex-column align-items-start active">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h5 class="mb-1">Materiais da aula</h5>
                                        </div>
                                    </span>
                                    <?php $__empty_2 = true; $__currentLoopData = $aula->materiais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <a href="<?php echo e(route('materiais.download', ['id' => $material->id])); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h5 class="mb-1"><?php echo e($material->titulo); ?></h5>
                                                <small class="text-muted"><i class="fas fa-download"></i></small>
                                            </div>
                                            <?php if(!empty($material->descricao)): ?>
                                            <p class="mb-1"><?php echo $material->descricao; ?></p>
                                            <?php endif; ?>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="list-group-item list-group-item-action flex-column align-items-start">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h5 class="mb-1">Nenhum material para esta aula.</h5>
                                            </div>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="row mt-3">
                    <div class="col">
                    <?php $__errorArgs = ['alunoMatriculado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php $__errorArgs = ['cursoNoPrazo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                    <?php $__errorArgs = ['aulaCorreta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo e($message); ?>

                        </div>                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                    
                    </div>
                </div>
                <?php endif; ?>

                <?php if($aulas): ?>
                <div class="row mt-3">
                    <div class="col-lg-12 mb-3 text-right">
                        <?php echo $aulas->appends(request()->query())->links(); ?>

                    </div>
                </div>
                <?php endif; ?>

                <?php if(!$aulas->hasMorePages() && !$curso->feedbackRespondido()): ?>
                <div class="row mt-3">
                    <div class="col-lg-12 mb-3">
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-trophy"></i>
                            <?php echo $curso->mensagem_conclusao; ?>

                            <br />
                            Por favor preencha o nosso questionário de avaliação para ter acesso ao seu certificado. <br />
                            <a href="<?php echo e(route('feedback', ['curso' => $curso->id])); ?>" class="btn btn-success">
                            PREENCHER QUESTIONÁRIO
                            </a>
                        </div>   
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/aula/index.blade.php ENDPATH**/ ?>