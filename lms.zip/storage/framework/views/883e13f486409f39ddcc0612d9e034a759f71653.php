<nav class="navbar navbar-expand-lg navbar-dark bg-aldeia">
    <?php if(auth()->guard()->guest()): ?>
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img class="img-fluid" style="width:100%" src="<?php echo e(asset('images/logo-aldeia.png')); ?>" />
        </a>
    <?php else: ?>
        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">
            <img class="img-fluid" style="width:100%" src="<?php echo e(asset('images/logo-aldeia.png')); ?>" />
        </a>
    <?php endif; ?>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
        aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div style="width: 100%">
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li><a class="nav-link " href="<?php echo e(route('login')); ?>"><?php echo e(__('Faça o login')); ?></a></li>
                    <!-- <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Cadastre-se')); ?></a></li> -->
                <?php else: ?>
                    
                    <li><span class="nav-link font-weight-bold"><?php echo e(Auth::user()->name); ?></span></li>
                    
                    <?php if(auth()->check() && auth()->user()->hasRole('Aluno')): ?>
                    <li><a class="nav-link" href="<?php echo e(route('home')); ?>">Acessar Curso</a></li>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('Admin|Gestor')): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Administração
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php if(auth()->check() && auth()->user()->hasRole('Gestor')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('matriculas.index')); ?>">Matrículas</a>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">Usuários</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item small"><strong>Clientes</strong></a>
                            <a class="dropdown-item" href="<?php echo e(route('planos.index')); ?>">Planos</a> 
                            <a class="dropdown-item" href="<?php echo e(route('empresas.index')); ?>">Empresas</a>                                    
                            <a class="dropdown-item" href="<?php echo e(route('matriculas.index')); ?>">Matrículas</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item small"><strong>Conteúdo</strong></a>
                            <a class="dropdown-item" href="<?php echo e(route('modulos.index')); ?>">Módulos</a>
                            <a class="dropdown-item" href="<?php echo e(route('aulas.index')); ?>">Aulas</a>
                            <a class="dropdown-item" href="<?php echo e(route('materiais.index')); ?>">Materiais</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item small"><strong>Feedbacks</strong></a>
                            <a class="dropdown-item" href="<?php echo e(route('questionarios.index')); ?>">Questionários</a>
                            <a class="dropdown-item" href="<?php echo e(route('perguntas.index')); ?>">Perguntas</a>
                            <a class="dropdown-item" href="<?php echo e(route('respostas.index')); ?>">Respostas</a>
                            <a class="dropdown-item" href="<?php echo e(route('feedbacks.index')); ?>">Visualizar feedbacks</a>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php endif; ?>

                    <li><a class="nav-link" href="<?php echo e(route('userslogged.index')); ?>">Meus dados</a></li>
                    <li><a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Sair</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>


                <?php endif; ?>
            </ul>
        </div>
        <?php if(Request::path() == 'quizzes/responder' && isset($quizz)): ?>
            <h4 class="pt-4 text-right"><?php echo $quizz->nome; ?></h4>
        <?php endif; ?>
    </div>
</nav><?php /**PATH D:\Atma\lms\resources\views/layouts/menu.blade.php ENDPATH**/ ?>