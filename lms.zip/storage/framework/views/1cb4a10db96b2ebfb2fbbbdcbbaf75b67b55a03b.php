

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <?php if(!isset($resposta->id) || intval($resposta->id) == 0): ?>
                        <i class="fas fa-plus"></i> Novo resposta
                    <?php else: ?>
                        <i class="fas fa-edit"></i> Editar resposta
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('respostas.index')); ?>"
                            class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                                class="fas fa-chevron-left"></i> Voltar</a>
                        <?php if(intval($resposta->id) > 0): ?>
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['respostas.destroy', $resposta->id], 'style'
                            => 'display:inline']); ?>

                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <p><strong>Whoops!</strong> Temos alguns problemas.</p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <?php if(!isset($resposta->id) || intval($resposta->id) == 0): ?>
                <?php echo Form::open(['route' => 'respostas.store', 'method' => 'POST', 'enctype' => 'multipart/form-data', 'id'
                => 'edit-form']); ?>

            <?php else: ?>
                <?php echo Form::model($resposta, ['method' => 'PATCH', 'enctype' => 'multipart/form-data', 'id' => 'edit-form',
                'route' => ['respostas.update', isset($resposta->id) ? $resposta->id : 0]]); ?>

            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php
                $curso_id = intval($resposta->id) == 0 ? 0 : $resposta->pergunta->questionario->curso->id ;
                ?>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="curso_id"><strong>Curso</strong></label>
                            <select id="curso_id" name="curso_id" class="form-control">
                                <option value="">Escolha...</option>
                                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($curso->id); ?>" <?php echo e($curso_id == $curso->id ? 'selected' : ''); ?>>
                                        <?php echo e($curso->nome); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="questionario_id"><strong>Questionário</strong></label>
                            <select id="questionario_id" name="questionario_id" class="form-control">
                                <?php if($curso_id > 0): ?>
                                    <option value="<?php echo e($resposta->pergunta->questionario->id); ?>" selected>
                                        <?php echo e($resposta->pergunta->questionario->nome); ?>

                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Pergunta:</strong>
                        <select id="pergunta_id" name="pergunta_id" class="form-control">
                            <?php if($curso_id > 0): ?>
                                <option value="<?php echo e($resposta->pergunta_id); ?>" selected><?php echo e($resposta->pergunta->titulo); ?>

                                </option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">

                    <div class="form-group">
                        <strong>Resposta:</strong>
                        <?php echo Form::text('resposta', $resposta->titulo, ['placeholder' => '', 'class' => 'form-control']); ?>

                    </div>

                </div>

                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="form-group">
                        <strong>Letra da resposta (A, B etc):</strong>
                        <?php echo Form::text('ordem', $resposta->ordem, ['placeholder' => '', 'class' => 'form-control']); ?>

                    </div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                            class="fas fa-save"></i> Salvar</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    <script src="<?php echo e(asset('node_modules/tinymce/tinymce.js')); ?>"></script>
    <script>
        tinymce.init({
            selector: 'textarea#descricao',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'bold italic | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat'
        });

    </script>

    <link href="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/css/dependent-dropdown.min.css')); ?>" media="all"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/dependent-dropdown.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/locales/pt-BR.js')); ?>"></script>

    <script>
        $("#questionario_id").depdrop({
            url: '/respostas/questionarios',
            depends: ['curso_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            initialize: true,
            initDepends: ['curso_id'],
        });

        $("#pergunta_id").depdrop({
            url: '/respostas/perguntas',
            depends: ['curso_id', 'questionario_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            initialize: false,
            initDepends: ['questionario_id'],
        });

    </script>

    <!-- Laravel Javascript Validation -->
    <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
    <?php echo $validator->selector('#edit-form'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/respostas/edit.blade.php ENDPATH**/ ?>