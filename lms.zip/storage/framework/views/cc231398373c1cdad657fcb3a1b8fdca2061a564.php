

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <?php if(!isset($material->id) || intval($material->id) == 0): ?>
                    <i class="fas fa-plus"></i> Novo material
                    <?php else: ?>
                    <i class="fas fa-edit"></i> Editar material
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="row">
                <div class="col-lg-6 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('materiais.index')); ?>"
                            class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                                class="fas fa-chevron-left"></i> Voltar</a> 
                        <?php if(intval($material->id) > 0): ?>
                            <?php echo Form::open(['method' => 'DELETE', 'route' =>
                            ['materiais.destroy', $material->id], 'style' => 'display:inline']); ?>

                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <p><strong>Whoops!</strong> Temos alguns problemas.</p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


            <?php if(!isset($material->id) || intval($material->id) == 0): ?>
                <?php echo Form::open(['route' => 'materiais.store', 'method' => 'POST', 'enctype' => 'multipart/form-data', 'id' => 'edit-form']); ?>

            <?php else: ?>
                <?php echo Form::model($material, ['method' => 'PATCH', 'enctype' => 'multipart/form-data', 'id' => 'edit-form',
                'route' => ['materiais.update', isset($material->id) ? $material->id : 0]]); ?>

            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php
                $curso_id = intval($material->id) == 0 ? 0 : $material->modulo->curso->id ;
                ?>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="curso_id"><strong>Curso:</strong></label>
                            <select id="curso_id" name="curso_id" class="form-control">
                                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($curso->id); ?>" <?php echo e($curso_id == $curso->id ? 'selected' : ''); ?>>
                                        <?php echo e($curso->nome); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="modulo_id"><strong>Módulo:</strong></label>
                            <select id="modulo_id" name="modulo_id" class="form-control">
                                <?php if($curso_id > 0): ?>
                                <option value="<?php echo e($material->modulo->id); ?>" selected>
                                    <?php echo e($material->modulo->nome); ?>

                                </option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Aula <span class="small">(Deixe em branco para cadastrar o material diretamente no módulo.)</span></strong>
                        <select id="aula_id" name="aula_id" class="form-control">
                            <?php if(intval($material->aula_id) > 0): ?>
                            <option value="<?php echo e($material->aula_id); ?>" selected><?php echo e($material->aula->titulo); ?></option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <strong>Nome:</strong>
                                <?php echo Form::text('titulo', $material->titulo, ['placeholder' => '', 'class' => 'form-control']); ?>

                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group">
                                <strong>Arquivo:</strong>
                                <div>
                                    <?php echo Form::file('arquivo', null, ['class' => 'form-control']); ?>

                                </div>
                                <div class="mt-2">
                                    <?php if(!empty($material->arquivo)): ?>
                                        <a class="btn btn-secondary btn-sm"
                                            href="<?php echo e(route('materiais.download', ['id' => $material->id])); ?>"><i
                                                class="fas fa-download"></i> Download</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Descrição:</strong>
                        <?php echo Form::textarea('descricao', $material->descricao, ['placeholder' => '', 'class' => 'form-control', 'id' =>
                        'descricao']); ?>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Ordem de aparição:</strong>
                        <?php echo Form::input('number', 'ordem', $material->ordem, ['placeholder' => '', 'class' => 'form-control col-1']); ?>

                    </div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                            class="fas fa-save"></i> Salvar</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    <script src="<?php echo e(asset('node_modules/tinymce/tinymce.js')); ?>"></script>
    <script>
        tinymce.init({
            selector: 'textarea#descricao',
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'bold italic | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat'
        });

    </script>

    <link href="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/css/dependent-dropdown.min.css')); ?>" media="all"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/dependent-dropdown.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/locales/pt-BR.js')); ?>"></script>

    <script>
        $("#modulo_id").depdrop({
            url: '/materiais/modulos',
            depends: ['curso_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            initialize: true,
            initDepends: ['curso_id'],
        });

        $("#aula_id").depdrop({
            url: '/materiais/aulas',
            depends: ['curso_id', 'modulo_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            initialize: false,
            initDepends: ['modulo_id'],
        });

    </script>

    <!-- Laravel Javascript Validation -->
    <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
    <?php echo $validator->selector('#edit-form'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/materiais/edit.blade.php ENDPATH**/ ?>