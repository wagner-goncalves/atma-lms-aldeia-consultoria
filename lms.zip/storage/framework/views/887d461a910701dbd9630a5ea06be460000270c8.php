

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <i class="fas fa-chalkboard-teacher"></i> Gerenciar perguntas
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('perguntas.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> Pergunta</a>
                    </div>
                </div>
            </div>            
            <div class="row">
                <div class="col-lg-12 col-sm-12">

                    <form method="GET" action="<?php echo e(\Request::getRequestUri()); ?>">
                        <div class="form-row">
                            <div class="form-group col">
                                <label for="questionario_id" class="small"><strong>Curso</strong></label>
                                <select id="curso_id" name="curso_id" class="form-control form-control-sm">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($curso->id); ?>" <?php echo e($curso_id == $curso->id ? 'selected' : ''); ?>>
                                            <?php echo e($curso->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="questionario_id" class="small"><strong>Questionário</strong></label>
                                <select id="questionario_id" name="questionario_id" class="form-control form-control-sm">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $questionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($questionario->id); ?>" <?php echo e($questionario_id == $questionario->id ? 'selected' : ''); ?>>
                                            <?php echo e($questionario->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="questionario_id" class="small"><strong>Palavra-chave</strong></label>
                                <input type="text" class="form-control form-control-sm" id="filter" name="filter"
                                        placeholder="Palavra-chave" value="<?php echo e($filter); ?>">
                            </div>
                            <div class="form-group col">
                                <label for="questionario_id" class="small"><strong>&nbsp;</strong></label>
                                <div>
                                    <button type="submit" class="btn btn-sm btn-secondary mb-2">Filtrar</button>
                                    &nbsp;<a href="<?php echo e(route('perguntas.index')); ?>" class="btn btn-sm btn-link mb-2">limpar</a>
                                </div>
                            </div>                            
                        </div>
                    </form>



                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-exclamation-circle fa-lg"></i> <?php echo e($message); ?>

                </div>
            <?php endif; ?>

            <table class="table table-bordered">
                <tr>
                    <th>#</th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('curso_nome', 'Curso'));?> / <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('questionario_nome', 'Questionário'));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('pergunta', 'Pergunta'));?></th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('ordem', 'Número'));?></th>
                    <th>Ações</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td class="small"><b>Curso:</b> <?php echo e($pergunta->questionario->curso->nome); ?><br />
                            <b>Questionario:</b> <?php echo e($pergunta->questionario->nome); ?>

                        </td>
                        <td><a href="<?php echo e(route('perguntas.edit', $pergunta->id)); ?>"><?php echo e($pergunta->pergunta); ?></a></td>
                        <td><?php echo $pergunta->ordem; ?></td>
                        <td nowrap>
                            <a class="btn btn-sm btn-primary" href="<?php echo e(route('perguntas.edit', $pergunta->id)); ?>"><i
                                    class="fas fa-edit"></i></a>
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['perguntas.destroy', $pergunta->id], 'style' =>
                            'display:inline']); ?>

                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route('respostas.index', ['pergunta_id' => $pergunta->id, 'questionario_id' => $pergunta->questionario->id, 'curso_id' => $pergunta->questionario->curso->id])); ?>">Respostas <i
                                class="fas fa-arrow-right"></i></a>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6"><i class="fas fa-frown"></i> Nenhum registro encontrado.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <?php echo $perguntas->appends(request()->query())->links(); ?>

        </div>
    </div>

    <link href="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/css/dependent-dropdown.min.css')); ?>" media="all"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/dependent-dropdown.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/locales/pt-BR.js')); ?>"></script>

    <script>
        $("#questionario_id").depdrop({
            url: '/respostas/questionarios',
            depends: ['curso_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            //initialize: true,
            //initDepends: ['curso_id'],
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/perguntas/index.blade.php ENDPATH**/ ?>