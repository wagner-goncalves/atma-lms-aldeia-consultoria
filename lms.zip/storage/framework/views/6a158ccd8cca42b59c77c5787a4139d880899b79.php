

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <i class="fas fa-briefcase"></i> Gerenciar planos
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('planos.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i> Plano</a>
                    </div>
                </div>
            </div>            
            <div class="row">                
                <div class="col-lg-12 col-sm-12">
                    <form method="GET" action="<?php echo e(\Request::getRequestUri()); ?>">
                        <div class="form-row">
                            <div class="form-group col">
                                <label for="empresa_id" class="small"><strong>Plano</strong></label>
                                <select id="empresa_id" name="empresa_id" class="form-control form-control-sm">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($empresa->id); ?>" <?php echo e($empresa_id == $empresa->id ? 'selected' : ''); ?>>
                                            <?php echo e($empresa->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="plano_id" class="small"><strong>Palavra-chave</strong></label>
                                <input type="text" class="form-control form-control-sm" id="filter" name="filter"
                                        placeholder="Palavra-chave" value="<?php echo e($filter); ?>">
                            </div>
                            <div class="form-group col">
                                <label for="plano_id" class="small"><strong>&nbsp;</strong></label>
                                <div>
                                    <button type="submit" class="btn btn-sm btn-secondary mb-2">Filtrar</button>
                                    &nbsp;<a href="<?php echo e(route('planos.index')); ?>" class="btn btn-sm btn-link mb-2">limpar</a>
                                    
                                </div>
                            </div>                            
                        </div>
                    </form>
                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" role="alert">
                    <i class="fas fa-exclamation-circle fa-lg"></i> <?php echo e($message); ?>

                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <i class="fas fa-exclamation-circle fa-lg"></i> <?php echo $message; ?>

                </div>
            <?php endif; ?>            

            <table class="table table-bordered">
                <tr>
                    <th>#</th>
                    
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('nome', 'Plano'));?></th>
                    <th>Empresas</th>
                    <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('descricao', 'Descrição'));?></th>
                    <th>Ações</th>
                </tr>

                <?php $__empty_1 = true; $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $empresas = $plano->empresas()->get();
                    ?>                
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><a href="<?php echo e(route('planos.edit', $plano->id)); ?>"><?php echo e($plano->nome); ?></a></td>
                        <td class="small"><b>Empresas:</b> 
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($empresa->nome); ?> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        
                        <td><?php echo $plano->descricao; ?></td>
                        <td nowrap>
                            <a class="btn btn-sm btn-primary" href="<?php echo e(route('planos.edit', $plano->id)); ?>"><i
                                    class="fas fa-edit"></i></a>
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['planos.destroy', $plano->id], 'style'
                            => 'display:inline']); ?>

                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
  
                            <?php echo Form::close(); ?>

                            <a class="btn btn-sm btn-secondary" href="<?php echo e(route('matriculas.index', ['plano_id' => $plano->id])); ?>">Matrículas <i
                                class="fas fa-arrow-right"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6"><i class="fas fa-frown"></i> Nenhum registro encontrado.</td>
                </tr>                
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <?php echo $planos->appends(request()->query())->links(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/planos/index.blade.php ENDPATH**/ ?>