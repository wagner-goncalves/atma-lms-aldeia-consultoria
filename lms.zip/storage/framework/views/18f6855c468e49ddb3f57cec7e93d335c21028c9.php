

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <i class="fas fa-file-signature"></i> Gerenciar matrículas
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <div class="row">
                <div class="col-lg-12 col-sm-12">
                    <div class="form-group">
                        <a href="<?php echo e(route('matriculas.create')); ?>" class="btn btn-success"><i class="fas fa-plus"></i>
                            Matricula</a>
                    </div>
                </div>
            </div>
            <form method="GET" action="<?php echo e(\Request::getRequestUri()); ?>" enctype='multipart/form-data'>
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="form-row">
                            <div class="form-group col">
                                <label for="empresa_id" class="small"><strong>Empresa</strong></label>
                                <select id="empresa_id" name="empresa_id" class="form-control form-control-sm">
                                    <option value="">Todas</option>
                                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($empresa->id); ?>"
                                            <?php echo e($empresa_id == $empresa->id ? 'selected' : ''); ?>>
                                            <?php echo e($empresa->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="plano_id" class="small"><strong>Plano</strong></label>
                                <select id="plano_id" name="plano_id" class="form-control form-control-sm">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($plano->id); ?>" <?php echo e($plano_id == $plano->id ? 'selected' : ''); ?>>
                                            <?php echo e($plano->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col">
                                <label for="curso_id" class="small"><strong>Curso</strong></label>
                                <select id="curso_id" name="curso_id" class="form-control form-control-sm">
                                    <option value="">Todos</option>
                                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($curso->id); ?>" <?php echo e($curso_id == $curso->id ? 'selected' : ''); ?>>
                                            <?php echo e($curso->nome); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="filter" class="small"><strong>Palavra-chave</strong></label>
                                <input type="text" class="form-control form-control-sm" id="filter" name="filter"
                                    placeholder="Palavra-chave" value="<?php echo e($filter); ?>">
                            </div>
                            <div class="form-group col">
                                <label class="small"><strong>&nbsp;</strong></label>
                                <div>
                                    <button type="submit" class="btn btn-sm btn-secondary mb-2">Filtrar</button>
                                    &nbsp;<a href="<?php echo e(route('matriculas.index')); ?>"
                                        class="btn btn-sm btn-link mb-2">limpar</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col-lg-6 col-sm-6">
                    <?php echo Form::open(['route' => 'matriculas.importar', 'method' => 'post', 'enctype' =>
                    'multipart/form-data', 'id' => 'form-matricula']); ?>

                    <script>
                        $(document).ready(function() {
                            $('#form-matricula').on('submit', function(e) {

                                var empresa = parseInt($("#empresa_id").val());
                                var plano = parseInt($("#plano_id").val());
                                var curso = parseInt($("#curso_id").val());

                                console.log(empresa, plano, curso);

                                if (empresa > 0 && plano > 0 && curso > 0) {
                                    if ($("#arquivo_matricula").val() == '') {
                                        $('#mensagem_modal').html(
                                            "Escolha um arquivo para importação das matrículas.");
                                        $('#modal-mensagem').modal();
                                    } else {
                                        $("#empresa_id_matricula").val(empresa);
                                        $("#plano_id_matricula").val(plano);
                                        $("#curso_id_matricula").val(curso);
                                        $("#btn-importar:first i").removeClass("fa-file-import").addClass(
                                            "fa-spin fa-spinner");
                                        return;
                                    }
                                } else {
                                    $('#mensagem_modal').html(
                                        "Para importar alunos e matriculá-los, escolha obrigatoriamente: a Empresa, o Plano contratado e o Curso."
                                    );
                                    $('#modal-mensagem').modal();
                                }

                                e.preventDefault();

                            });
                        });

                    </script>

                    <?php echo Form::hidden('empresa_id', null, ['id' => 'empresa_id_matricula']); ?>

                    <?php echo Form::hidden('plano_id', null, ['id' => 'plano_id_matricula']); ?>

                    <?php echo Form::hidden('curso_id', null, ['id' => 'curso_id_matricula']); ?>


                    <div class="modal" tabindex="-1" role="dialog" id="modal-mensagem">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Atenção!</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <p id="mensagem_modal"></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body small">
                            <h5 class="card-title">Importar arquivo de matrículas</h5>
                            <p class="card-text">Obrigatóriamente, use os filtros acima para indicar em qual curso serão realizadas as matrículas importadas. Veja o <a href="<?php echo e(asset('docs/Exemplo_Importacao_Matriculas.xlsx')); ?>">exemplo</a> de arquivo de matrículas.</p>
                            <p class="card-text"><input name="arquivo" type="file" id="arquivo_matricula"></p>
                            <button id="btn-importar" type="submit" class="btn btn-sm btn-primary mb-2"><i
                                    class="fas fa-file-import fa-lg"></i> Importar</button>
                        </div>
                    </div>


                    <?php echo Form::close(); ?>

                </div>

                <div class="col-lg-6 col-sm-6">
                    <?php echo Form::open(['route' => 'matriculas.exportar', 'method' => 'post', 'id' => 'form-exportar']); ?>

                    <script>
                        $(document).ready(function() {
                            $('#form-exportar').on('submit', function(e) {

                                var empresa = parseInt($("#empresa_id").val());
                                var plano = parseInt($("#plano_id").val());
                                var curso = parseInt($("#curso_id").val());

                                $("#empresa_id_exportar").val(empresa);
                                $("#plano_id_exportar").val(plano);
                                $("#curso_id_exportar").val(curso);

                                return;

                                //e.preventDefault();

                            });
                        });

                    </script>

                    <?php echo Form::hidden('empresa_id', null, ['id' => 'empresa_id_exportar']); ?>

                    <?php echo Form::hidden('plano_id', null, ['id' => 'plano_id_exportar']); ?>

                    <?php echo Form::hidden('curso_id', null, ['id' => 'curso_id_exportar']); ?>




                    <div class="card">
                        <div class="card-body small">
                            <h5 class="card-title">Exportar dados de alunos e matrículas</h5>
                            <p class="card-text">Opcionalmente, use os filtros acima para personalizar o relatório.</p>
                            <button id="btn-exportar" type="submit" class="btn btn-sm btn-primary mb-2"><i
                                    class="fas fa-file-excel fa-lg"></i> Exportar</button>
                        </div>
                    </div>



                    <?php echo Form::close(); ?>

                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-12 col-sm-12">

                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-exclamation-circle fa-lg"></i> <?php echo e($message); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if($quantidadeAlunosMatriculados != ""): ?>
                    <hr />
                        <h4 class="pull-right"><?php echo e($quantidadeAlunosMatriculados); ?> de <?php echo e($quantidadePermitida); ?> matrículas.</h4>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <tr>
                            <th>#</th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('empresa_nome', 'Empresa'));?> / <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('plano_nome', 'Plano'));?> /
                                <?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('curso_nome', 'Curso'));?></th>
                            <th>Matrícula</th>
                            <th>Aluno</th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('data_limite', 'Data limite'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('data_conclusao', 'Data de conclusão'));?></th>
                            <th>Ações</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $matriculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td class="small"><b>Empresa:</b> <?php echo e($matricula->empresa->nome); ?><br />
                                    <b>Plano:</b> <?php echo e($matricula->plano->nome); ?><br />
                                    <b>Curso:</b> <?php echo e($matricula->curso->nome); ?>

                                </td>
                                <td><a href="<?php echo e(route('matriculas.edit', $matricula->id)); ?>"><?php echo e($matricula->id); ?></a></td>
                                <td><a href="<?php echo e(route('matriculas.edit', $matricula->id)); ?>"><?php echo e($matricula->user->name); ?></a>
                                </td>
                                <td><?php echo e(\Carbon\Carbon::parse($matricula->data_limite)->format('d/m/Y')); ?></td>
                                <td><?php echo e(empty($matricula->data_conclusao) ? 'Não concluído' : \Carbon\Carbon::parse($matricula->data_conclusao)->format('d/m/Y')); ?>

                                </td>
                                <td nowrap>
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('matriculas.edit', $matricula->id)); ?>"><i
                                            class="fas fa-edit"></i></a>
                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['matriculas.destroy', $matricula->id],
                                    'style' => 'display:inline']); ?>

                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6"><i class="fas fa-frown"></i> Nenhum registro encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-3">
            <?php echo $matriculas->appends(request()->query())->links(); ?>

        </div>
    </div>

    <link href="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/css/dependent-dropdown.min.css')); ?>" media="all"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/dependent-dropdown.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('vendor/kartik-v/dependent-dropdown/js/locales/pt-BR.js')); ?>"></script>

    <script>
        $("#plano_id").depdrop({
            url: '/matriculas/planos',
            depends: ['empresa_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            //initialize: true,
            //initDepends: ['curso_id'],
        });

        $("#curso_id").depdrop({
            url: '/matriculas/cursos',
            depends: ['plano_id', 'empresa_id'],
            loadingText: 'Carregando...',
            placeholder: 'Escolha...',
            //initialize: true,
            //initDepends: ['curso_id'],
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/matriculas/index.blade.php ENDPATH**/ ?>