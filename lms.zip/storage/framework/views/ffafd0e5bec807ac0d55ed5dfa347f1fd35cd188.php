

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left pb-3">
                <div class="titulo-destaque">
                    <i class="fas fa-key"></i> Reiniciar sua senha
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 margin-tb">

            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12">

                        <a href="<?php echo e(route('home')); ?>" class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i class="fas fa-check"></i> ACESSAR CURSO</a>

                    </div>    
                </div>            
            <?php else: ?>
                <div class="alert alert-danger">
                    Este é o seu primeiro acesso. Para sua segurança, cadastre uma senha personalizada.
                    <br /><strong>Importante:</strong> o seu próximo acesso será realizado com a senha deste cadastro.

                </div>

                <form class="form-horizontal" method="POST" action="<?php echo e(route('password.post_expired')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">



                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-row">
                                <div class="form-group col-md-6<?php echo e($errors->has('current_password') ? ' has-error' : ''); ?>">
                                    <label for="current_password" class="control-label">Senha atual</label>
                                    <input id="current_password" type="password" class="form-control"
                                        name="current_password" required="">

                                    <?php if($errors->has('current_password')): ?>
                                        <span class="text-danger">
                                            <strong><?php echo e($errors->first('current_password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-row">

                                <div class="form-group col-md-6<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label for="password" class="control-label">Nova senha</label>
                                    <input id="password" type="password" class="form-control" name="password" required="">

                                    <?php if($errors->has('password')): ?>
                                        <span class="text-danger">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div
                                    class="form-group col-md-6<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                    <label for="password-confirm" class="control-label">Confirmar nova senha</label>
                                    <input id="password-confirm" type="password" class="form-control"
                                        name="password_confirmation" required="">

                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="text-danger">
                                            <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit"
                                        class="btn btn-success pr-4 pl-4 text-dark font-weight-bold text-uppercase"><i
                                            class="fas fa-save"></i> Reiniciar senha</button>
                                </div>
                            </div>
                        </div>


                    </div>
                </form>


            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/auth/passwords/expired.blade.php ENDPATH**/ ?>