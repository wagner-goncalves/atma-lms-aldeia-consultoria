<?php $__env->startSection('title', __('Sessão expirada')); ?>
<?php $__env->startSection('code', '419'); ?>
<?php $__env->startSection('message', __('A página que você acessou está há muito tempo sem atualização e não é mais válida. Por favor, clique em voltar em seu navegador e atualize a página.')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Atma\lms\resources\views/errors/419.blade.php ENDPATH**/ ?>