<!-- FOOTER -->
<footer>
    <div class="container-fluid bg-banner">
        <div class="row">
            <div class="col-md-9 py-3 px-3 text-white font-weight-bold">
                Aldeia Consultoria © {{ date('Y') }} | contato@aldeiaconsultoria.com.br | (31) 99106-6565
            </div>
            <div class="col-md-3 py-3 px-3 text-right">
                <a href="https://atmainterativa.com.br" target="blank" rel="noopener noreferrer">
                    <img src="{{ asset('images/assinatura-atma.png') }}" width="70" />
                </a>
            </div>
        </div>
    </div>
<footer>